#ifndef BOOST_NUMERIC_SAFE_RANGE_HPP
#define BOOST_NUMERIC_SAFE_RANGE_HPP

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

//  Copyright (c) 2012 Robert Ramey
//
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cstdint> // intmax_t, uintmax_t

#include "utility.hpp"
#include "safe_base.hpp"
#include "safe_base_operations.hpp"
#include "native.hpp"
#include "exception_policies.hpp"

/////////////////////////////////////////////////////////////////
// higher level types implemented in terms of safe_base

namespace boost {
namespace numeric {

/////////////////////////////////////////////////////////////////
// safe_signed_range

template <
    std::intmax_t Min,
    std::intmax_t Max,
    class P = native,
    class E = throw_exception
>
using safe_signed_range = safe_base<
    typename boost::numeric::signed_stored_type<Min, Max>,
    static_cast<typename boost::numeric::signed_stored_type<Min, Max> >(Min),
    static_cast<typename boost::numeric::signed_stored_type<Min, Max> >(Max),
    P,
    E
>;

/////////////////////////////////////////////////////////////////
// safe_unsigned_range

template <
    std::uintmax_t Min,
    std::uintmax_t Max,
    class P = native,
    class E = throw_exception
>
using safe_unsigned_range = safe_base<
    typename boost::numeric::unsigned_stored_type<Min, Max>,
    static_cast<typename boost::numeric::unsigned_stored_type<Min, Max> >(Min),
    static_cast<typename boost::numeric::unsigned_stored_type<Min, Max> >(Max),
    P,
    E
>;

} // numeric
} // boost

#endif // BOOST_NUMERIC_SAFE_RANGE_HPP
